# show xroads cmd line options
#./xroads.app -h

# create log file from output for debugging
#./xroads.app > xroads.log

# reduce car velocity to 80%
#./xroads.app -v 80

echo "press any key ..."
read
